  Cache cache(associativity, blocksize_bytes, cachesize_kb, miss_penalty);
