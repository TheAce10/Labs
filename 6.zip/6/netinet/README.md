netinet
=======

Just a dump of the FreeBSD sys/netinet files as of February 5th 2013. Can be used in your C/C++/Objective C networking needs.

Why?
----

Because sometimes you want these headers and your goddamn distribution doesn't include them. Then you find that you want to give some Berkeley-style socket programming love to your C/C++/Objective C app and your static compiler pitches a fit. Hopefully what you need is here.